document.addEventListener('DOMContentLoaded', function() {
    const navbar = document.getElementById('navbar');
    const menuIcon = document.getElementById('menu-icon');
    const slideMenu = document.getElementById('slide-menu');
    const sections = document.querySelectorAll('.section-background');
  
    const navbarLinks = document.querySelectorAll('.navbar ul li a');
    navbarLinks.forEach((link) => {
        link.addEventListener('click', function(e) {
            e.preventDefault(); 
            const targetId = link.getAttribute('href').substring(1); 
            const targetSection = document.getElementById(targetId);
            if (targetSection) {
                targetSection.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
  
    
    if (menuIcon && slideMenu) {
        menuIcon.addEventListener('click', function() {
            slideMenu.classList.toggle('show');
        });
  
        const slideMenuLinks = document.querySelectorAll('.slide-menu ul li a');
        slideMenuLinks.forEach((link) => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const targetId = this.getAttribute('href').substring(1);
                const targetSection = document.getElementById(targetId);
                if (targetSection) {
                    targetSection.scrollIntoView({ behavior: 'smooth' });
                }
                slideMenu.classList.remove('show');
            });
        });
    }
  
    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });
  
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, { threshold: 0.2 }); 
  
    sections.forEach(section => {
        observer.observe(section);
    });
  });
  